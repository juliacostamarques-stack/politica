# Voto Consciente

Site educativo sobre consciência política, com foco em orientação sobre voto e eleições.

## Estrutura

- `index.html` — página inicial
- `artigos.html` — listagem de artigos
- `como-funciona-o-voto.html`, `fake-news-eleitoral.html`, `direitos-e-deveres.html` — artigos individuais
- `recursos.html` — links oficiais, checklist do dia da votação e glossário
- `style.css` — estilo compartilhado por todas as páginas

## Como publicar no GitHub Pages

1. Crie um repositório novo no GitHub (ex.: `voto-consciente`).
2. Faça upload de todos os arquivos deste pacote para a raiz do repositório.
3. Vá em **Settings → Pages**.
4. Em "Source", selecione a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
5. Em 1–2 minutos o site estará no ar em `https://<seu-usuario>.github.io/voto-consciente/`.

## Adicionando novos artigos

Duplique um dos arquivos de artigo existentes, edite o título e o conteúdo, e adicione um link para ele em `artigos.html` (e, se quiser, em `index.html`).
